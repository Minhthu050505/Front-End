/*!
 * 
 * Perfume eCommerce HTML5 Template v.1.0.0
 * 
 */


jQuery(function($) {
	"use strict";

	$(window).load(function() {

		/*** preload animation ***/
		setTimeout(function() {
			$('body').addClass('loaded');
		}, 500);

		/*** newsletter script ***/
		setTimeout(function() {
			if ($('.newsletter-holder').length) {
				$('body').addClass('newsletter-open');
			}
		}, 5000);

	});


	/*** dropBox functionality ***/

	$('.dropBox-btn').on('click', this, function() {

		$('.dropBox-btn').not(this).closest('li').removeClass('open');
		$(this).closest('li').toggleClass('open');
	});

	var $dropboxParent = $('.dropBox-btn').closest('li');

	$(document).mouseup(function(e) {

		if (!$dropboxParent.is(e.target) && $dropboxParent.has(e.target).length === 0) {
			$dropboxParent.removeClass('open');
		}
	});

	$(document).keyup(function(e) {
		if (e.keyCode == 27) {
			$dropboxParent.removeClass('open');
		}
	});

	$('.dismiss-button').on('click', this, function() {
		$(this).closest('li').removeClass('open');
	});

	$('.main-nav li').has('ul').addClass('has-ul');
	$('.main-nav li.has-ul').prepend('<span class="menu-sibling"/>');


	$('.menu-sibling').on('click', this, function() {
		$(this).next('ul').toggle();
		$(this).closest('li').toggleClass('open');
	});

	$('.toggle-menu').on('click', this, function() {
		$(this).toggleClass('open');
	});

	$('.newsletter-cover').on('click', this, function() {
		$('body').removeClass('newsletter-open');
	});

	if ($('.carousel-single').length) {

		$(".carousel-single").each(function() {

			var cSingle = $(this),
				trans = cSingle.data('trans'),
				caroNext = '.' + cSingle.data('btn-next'),
				caroPrev = '.' + cSingle.data('btn-prev');

			cSingle.owlCarousel({
				autoPlay: true,
				singleItem: true,
				pagination: false,
				autoHeight: true,
				transitionStyle: trans
			});

			$(caroNext).on('click', this, function() {
				cSingle.trigger('owl.next');
				console.log('next');
			});
			$(caroPrev).on('click', this, function() {
				cSingle.trigger('owl.prev');
			});

		});

	}

	if ($('.carousel-multiple').length) {
		var cSingle = $(".carousel-multiple");

		cSingle.owlCarousel({
			autoPlay: true,
			pagination: false,
			items: 4,
			itemsDesktop: [1199, 3],
			itemsDesktopSmall: [979, 3]
		});

		$(".caro-next").on('click', this, function() {
			cSingle.trigger('owl.next');
		});
		$(".caro-prev").on('click', this, function() {
			cSingle.trigger('owl.prev');
		});
	}

	/*** select parent checkbox on checking child one ***/
	$('input.checkChild').on('change', this, function() {
		if ($(this).is(':checked')) {
			$(this).closest('ul').siblings('.checkbox').find('.checkParent').attr('checked', true);
		}
		else {
			$(this).closest('ul').siblings('.checkbox').find('.checkParent').attr('checked', false);
		}
	});

	/*** convert tp-menu into select **/
	/*	$("<select />").appendTo(".site-footer .container");
		
		$("<option />", {
			 "selected": "selected",
			 "value"   : "",
			 "text"    : "Categories"
		}).appendTo(".site-footer .container select");
		
		$(".footer-links li a").each(function() {
		 var el = $(this);
		 $("<option />", {
				 "value"   : el.attr("href"),
				 "text"    : el.text()
		 }).appendTo(".site-footer .container select");
		});
		
		$(".site-footer .container select").change(function() {
			window.location = $(this).find("option:selected").val();
		});*/ /*** convert tp-menu ends ***/


	/*** our team page tabs funcitonality ***/
	$('.team-boxes a').on('click', this, function(e) {

		var $this = $(this);

		$this.tab('show');
		$('.team-boxes a').not(this).removeClass('active');
		$this.addClass('active');
		e.preventDefault();
	});
	$('a.scroll-tab').on('click', this, function(e) {
		var href = $(this).attr('href');
		$('html, body').animate({ scrollTop: $(href).offset().top - 30 }, 600);
		e.preventDefault();
	});

	/*** Accordion ***/
	if ($('.accordion').length) {
		$('.accordion').collapse();
	}

	$('.panel-collapse').on('show.bs.collapse', function() {
		$(this).prev('.panel-heading').addClass("active-heading");
	});

	$('.panel-collapse').on('hide.bs.collapse', function() {
		$(this).prev('.panel-heading').removeClass("active-heading");
	});

	/*** Breadcrumb dropdown and search ***/
	$('.breadcrumb-search .dropdown-menu a').on('focus', this, function() {
		var txt = $(this).text();
		$('.breadcrumb-search > a').text(txt).append(' <i class="caret"></i>');
		$('.bar-form input[type="search"]').attr('placeholder', 'Search within ' + txt);
	});

	$('[data-toggle="popover"]').popover();

	$('input.trigger-other-shippment-info').change(function() {
		if ($(this).is(':checked')) {
			$('.other-shippment-info').slideDown('fast');
		}
		else {
			$('.other-shippment-info').slideUp('fast');
		}
	});

	$('[data-jump]').each(function() {

		$(this).on('click', function() {
			var jump = '#' + $(this).data('jump');
			$('html, body').animate({ scrollTop: $(jump).offset().top - 10 }, 600);
		});

	});

	// Filter tabs mixitup
	if ($('.filter-list').length) {
		$('.filter-list').mixitup({
			layoutMode: 'grid',
			listClass: 'layout-list',
			gridClass: 'layout-grid',
			targetDisplayGrid: 'inline-block',
			targetDisplayList: 'block'
		});
	}

	if (!$('html').hasClass('ie-lt-10')) {

		$('.filter-tabs').on('click', '.layout-list', function() {
			$('.filter-list').mixitup('toList');
			$('.filter-tabs .layout-grid').removeClass('active');
			$(this).addClass('active');

		});

		$('.filter-tabs').on('click', '.layout-grid', function() {
			$('.filter-list').mixitup('toGrid');
			$('.filter-tabs .layout-list').removeClass('active');
			$(this).addClass('active');

		});

	} else {

		$('.filter-tabs').on('click', '.layout-list', function() {
			$('.filter-tabs .layout-grid').removeClass('active');
			$('.filter-list').addClass('layout-list');
			$('.filter-list').removeClass('layout-grid');
			$(this).addClass('active');

		});

		$('.filter-tabs').on('click', '.layout-grid', function() {
			$('.filter-list').addClass('layout-grid');
			$('.filter-list').removeClass('layout-list');
			$('.filter-tabs .layout-list').removeClass('active');
			$(this).addClass('active');
		});

	}

	/*** Search List Filtering
	---------------------------------------------------------------------------***/

	$('[name="SearchProdList"]').keyup(function(e) {
		var code = e.keyCode || e.which;
		if (code == '9') return;
		if (code == '27') $(this).val(null);
		var $rows = $(this).closest('[name="filter-base"]').find('[name="filter-list"] li');
		var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
		$rows.show().filter(function() {
			var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
			return !~text.indexOf(val);
		}).hide();
	});

	$('[name="clear-filter-list"]').on('click', this, function() {
		var $filterParent = $(this).closest('[name="filter-base"]');
		$filterParent.find('[name="filter-list"] li').show();
		$filterParent.find('[name="filter-list"] input[type="checkbox"]').attr('checked', false);
		$filterParent.find('[name="SearchProdList"]').val(null);
	});


	/*** jquery UI Slider
	----------------------------------------------------------------------- ***/

	/*if ( $( ".slider-element" ).length ) {
		$( ".slider-element" ).slider({
			range: true,
			min: 5,
			max: 1000,
			values: [ 75, 300 ],
			slide: function( e, ui ) {
				e = null;
				$( ".slide-min" ).text( "$" + ui.values[ 0 ] );
				$( ".slide-max" ).text( "$" + ui.values[ 1 ] );
			}
		});
		$( ".slide-min" ).text( "$" + $( ".slider-element" ).slider( "values", 0 ));
		$( ".slide-max" ).text( "$" + $( ".slider-element" ).slider( "values", 1 ));
	}*/


	/*** countdown timer ***/

	if ($('.defaultCountdown').length) {
		var countDay = new Date();
		//countDay = new Date(countDay.getFullYear() + 1, 1 - 1, 26);
		countDay = new Date(2015, 6 - 1, 25);
		$('.defaultCountdown').countdown({
			until: countDay
		});
	}


});

    const btn = document.querySelectorAll("button.btn_add");
const icon = document.querySelector(".icon_cart");
const cart = document.querySelector(".shoppping_cart tbody");
const cartBadge = document.querySelector(".badge");

btn.forEach(function(a) {
    a.addEventListener("click", function(event) {
        console.log('Button clicked!');
        var btnItem = event.target
        var product = btnItem.parentElement;
            var productName = product.querySelector("h3").innerText
            /*var productImg = product.querySelector('img').src
            console.log('productImg:', productImg);*/
            var productPrice = product.querySelector(".prod-price").innerText
            // Update giao diện từ front end
            var addedSuccessfully = addCart( productName, productPrice);
            if (addedSuccessfully) {
                updateCartBadge(true)
            }
    });
});


function addCart(productName, productPrice) {
	var addtr = document.createElement("tr");
	var cartItem = document.querySelectorAll("tbody tr");
	for (i = 0; i < cartItem.length; i++) {
		var productT = document.querySelectorAll("h3")
		if (productT[i].innerHTML == productName) {
			alert('đã có sản phẩm trong giỏ hàng')
			return false;
		}
	}


	var trContent = '<tr><td style="display: flex; align-items: center;"><h3>' + productName + '</h3></td><td><p><span class="product-price">' + productPrice + '</span></p></td><td><input style="width: 30px;outline:none;" type="number" value="1" min="0"></td><td style="cursor: pointer;">xóa</td></tr>'
	addtr.innerHTML = trContent
	var cartTable = document.querySelector("tbody");
	cartTable.appendChild(addtr)
	
	const quantityInput = addtr.querySelector("input");
    quantityInput.addEventListener("input", function() {
        cartTotal(); // Tính lại tổng khi số lượng thay đổi
    });

	const deletProducte = addtr.querySelector("td:last-child");
	deletProducte.addEventListener("click", function() {
		cartTable.removeChild(addtr);
		updateCartBadge(false);
		cartMinus(productPrice);
	});
	return true;
}

let cartCount = 0;
function updateCartBadge(increase = true) {
	if (increase) {
		cartCount++;
	} else {
		cartCount--;
	}
	cartBadge.textContent = cartCount;
}

function cartTotal() {
	var cartItem = document.querySelectorAll("tbody tr");
	var totalB = 0;
	for (i = 0; i < cartItem.length; i++) {
		var valueInput = cartItem[i].querySelector("input").value || 0;
		var price = parseFloat(cartItem[i].querySelector(".product-price").innerHTML) || 0;
		var totalA = valueInput * price;
		totalB = totalB + totalA;
	}
	var carttotalA = document.querySelector(".price_total span")
	carttotalA.innerHTML = totalB
	if (cartItem.length === 0) {
		carttotalA.innerHTML = 0;
	}
	
	if(valueInput ++) {
		price * valueInput;
	}
	console.log(carttotalA);
}

function cartMinus(productPrice) {
	var cartTotalElement = document.querySelector(".price_total span");
	var currentTotal = parseFloat(cartTotalElement.innerHTML) || 0;
	var price = parseFloat(productPrice) || 0;
	var newTotal = currentTotal - (price * 1000);
	if (newTotal < 0) {
		newTotal = 0;
	}
	cartTotalElement.innerHTML = newTotal;
}