package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/perfume";
	private static String username = "root";
	private static final String password = "root";

	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = getConnection();
			System.out.println(conn);
		} catch (Exception e) {
			System.out.println("Error connect! Error is: " + e.getMessage());
		}
	}

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(JDBC_URL, username, password);
	}

	public static void main(String[] args) {
		new DBConnection();
	}

}
