package DAO;

public class FactoryProduct {
private static FactoryProduct instance = new FactoryProduct();
	
	public static FactoryProduct getInstance() {
		return instance;
	}
	
	public ObjectDAO getProductDAO() {
		return (ObjectDAO) new ProductDAOImp();
	}
}
