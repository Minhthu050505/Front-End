package model;

public interface IModel {

}
