package Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.FactoryProduct;
import DAO.ObjectDAO;
import model.Product;

@WebServlet("/deleteServletProduct")
public class DeleteProductServlet extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		try {			
			String id = req.getParameter("id");
			
			
			ObjectDAO dao = FactoryProduct.getInstance().getProductDAO();
			Product product = dao.delete(id);
			req.getSession().setAttribute("product", product);
			if (id != null) {
				ObjectDAO opjDAO = FactoryProduct.getInstance().getProductDAO();
				List<Product> products = opjDAO.getAll();
				System.out.println("Number of product: " + products.size());
				req.getSession().setAttribute("products", products);
				resp.sendRedirect(req.getContextPath() + "/index.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		doPost(arg0, arg1);
	}
}
