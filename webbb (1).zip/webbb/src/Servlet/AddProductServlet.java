package Servlet;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.FactoryProduct;
import DAO.ObjectDAO;
import model.Product;

@WebServlet("/addProductServlet")
public class AddProductServlet extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
		try {			
			String id = req.getParameter("id");
			String productName = req.getParameter("productName");
			String imgsrc = req.getParameter("imgsrc");
			double productPrice = Double.parseDouble(req.getParameter("productPrice"));
			
			ObjectDAO dao = FactoryProduct.getInstance().getProductDAO();
			Product product = dao.insert(id, productName, imgsrc, productPrice);
			req.getSession().setAttribute("product", product);
			if (id != null && productName != null && imgsrc != null && productPrice != 0.0) {
				ObjectDAO opjDAO = FactoryProduct.getInstance().getProductDAO();
				List<Product> products = opjDAO.getAll();
				System.out.println("Number of product: " + products.size());
				req.getSession().setAttribute("products", products);
				resp.sendRedirect(req.getContextPath() + "/index.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		doPost(arg0, arg1);
	}
}
