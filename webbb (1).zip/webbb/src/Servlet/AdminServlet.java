package Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.FactoryProduct;
import DAO.ObjectDAO;
import model.Product;


@WebServlet("/adminServlet")
public class AdminServlet extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = req.getParameter("action");
		// Xử lý đăng xuất
		if ("logout".equals(action)) {
			if (req.getSession().getAttribute("user") != null) {
				// Nếu đang đăng nhập, xóa thông tin người dùng khỏi session
				req.getSession().removeAttribute("user");
				// Chuyển hướng về trang web
				resp.sendRedirect("productServlet");
				return;
			}
		}
		try {
			ObjectDAO productDAO = FactoryProduct.getInstance().getProductDAO();
			List<Product> productAdmin = productDAO.getAll();
			req.getSession().setAttribute("productAdmin", productAdmin);
			RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
			rd.forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			doGet(req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
