package Servlet;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ContactFormServlet")
public class ContactFormServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		// retrieve form data
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone");
		String comment = req.getParameter("comments");
	
		// Admin's email address
		String adminEmail = "21130211@st.hcmuaf.edu.vn";
	
		// email configuration
		Properties properties = new Properties();
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", "587");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
	
		// create a session object
		Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				// Thay thế email và password của bạn
				return new PasswordAuthentication("21130211@st.hcmuaf.edu.vn", "zsty rguo rwgd befu");
			}
		});
	
		try {
			MimeMessage message = new MimeMessage(session);
	
			// set the sender and recipient's addresss
			message.setFrom(new InternetAddress(adminEmail));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(adminEmail));
	
			// set the subject and text of the message
			message.setSubject("New Contact form submisssion");
			message.setText("Name: " + name + "\nEmail: " + email + "\nPhone: " + phone + "\nComments: " + comment);
	
			// Send the message
			Transport.send(message);
	
			// Redirect to thank you page or display a success message
			resp.sendRedirect("thankyou.jsp");
	
		} catch (MessagingException e) {
			e.printStackTrace();
			resp.sendRedirect("error.jsp");
		}
	
	}

}
